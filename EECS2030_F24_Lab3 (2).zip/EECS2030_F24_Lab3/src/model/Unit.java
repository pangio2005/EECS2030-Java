package model;

public class Unit {
    private String room;
    private int width;
    private int length;
    private double widMet;
    private double lenMet;
    private boolean metre;
    private String widRounded;
    private String lenRounded;
    private double area;
    private String areaRounded;

    public Unit(String room, int width, int length) {
        this.room = room;
        this.width = width;
        this.length = length;    
        metre = false;
    }
    
    public Unit(Unit other) {
        this.room = other.room;
        this.width = other.width;
        this.length = other.length;
        this.metre = other.metre; 
    }

    public void toogleMeasurement() {
        if (metre) {
            metre = false;
        } 
        
        else {
            this.widMet = 0.3048 * width;
            widRounded = String.format("%.2f", widMet);

            this.lenMet = 0.3048 * length;
            lenRounded = String.format("%.2f", lenMet); 
            
            this.area = widMet * lenMet;
            areaRounded = String.format("%.2f", area);
            metre = true; 
        }
    }

    public int getAreaInSquareFeet() {
        return width * length;
    }
  
    @Override
    public boolean equals(Object obj) {
    	boolean ans = false;
        Unit other = (Unit) obj; 
        
        double compare = getAreaInSquareFeet() - other.getAreaInSquareFeet();
        
        if(room.equals(other.room) && compare == 0) {
        	ans = true;
        }

        
        return ans;

    }  
    
    public String StringForArray() {
    	return room + ": " + getAreaInSquareFeet() + " sq ft (" + width + "' by "+ length + "')";

    }

    public String toString() {
        if (metre == true) {
            return "A unit of " + areaRounded + " square meters (" + widRounded
                    + " m wide and " + lenRounded + " m long) functioning as " + room;
        } 
        
        else {
            return "A unit of " + (width * length) + " square feet (" + width
                + "' wide and " + length + "' long) functioning as " + room;
        }
    }
}
