package model;

public class Blueprint {
	private int floors;
	private Blueprint blueprint;
	private Floor[] floorList;
	private int floorCount;

	
	public Blueprint(int floors) {
		this.floors = floors;
		this.floorList = new Floor[floors];
		this.floorCount = 0;
	}
	
	public Blueprint(Blueprint other) {
		this.floors = other.floors;
		this.floorList = new Floor[floors];
		this.floorCount = other.floorCount;
        for (int i = 0; i < floorCount; i++) {
            this.floorList[i] = new Floor(other.floorList[i]);
        }
	} 
	
	public void addFloorPlan(Floor floor) {
		floorList[floorCount] = floor;
		floorCount++;
	}
	
	public Floor[] getFloors() {
		Floor[] floorListSoFar = new Floor[floorCount];
		
        for (int i = 0; i < floorCount; i++) {
            floorListSoFar[i] = new Floor(floorList[i]);
        }
        
		return floorListSoFar;  
	}
	 
	public String calcPerc() {
		double percent = ((double)floorCount / (double)floors)  * 100;
        String percRound = String.format("%.1f", percent);
 
		return percRound;
	}
	
	public String toString() {
		if(floorCount == 0) {
			return "0.0 percents of building blueprint completed (0 out of 7 floors)";
		}
		
		else {
			return calcPerc() + " percents of building blueprint completed (" + floorCount + " out of " + floors +" floors)";
			
		}
		
	}
} 
