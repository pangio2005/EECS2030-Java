package model;

public class InsufficientFloorSpaceException extends Exception {
    public InsufficientFloorSpaceException() {
    	
    }
    

}