package model;


public class Floor {
	private int measurement;
	private Unit[] unitList;
	private int unitCount;
	private Floor floor;
	
	public Floor(int measurement)  {
		this.measurement = measurement;
		this.unitList = new Unit[20];
		this.unitCount = 0;
		
	}
	
    public Floor(Floor other) {
        this.measurement = other.measurement;
        this.unitList = new Unit[20];
        this.unitCount = other.unitCount;
        for (int i = 0; i < unitCount; i++) {
            this.unitList[i] = new Unit(other.unitList[i]);
        }
    }
	
	public Unit addUnit(String room, int width, int length) throws InsufficientFloorSpaceException {
		if(((width*length) + sumCalc()) > measurement) {
			throw new InsufficientFloorSpaceException();
		} 
		 
		else {
			unitList[unitCount] = new Unit(room, width, length);
			unitCount++;
			return unitList[unitCount];
		}
		
	}
	
	private int sumCalc() {
		int sum = 0;
		for(int i=0;i<unitCount;i++) {
			sum+= unitList[i].getAreaInSquareFeet();
		}
		
		return sum;
	}
	
	
	public int RemainingArea() {
		int ans = measurement - sumCalc();
		return ans;
	}
	
	
	public String ArraytoList() {
		String s = "";
		for(int i=0;i<unitCount;i++) {
			if (i == unitCount-1) {
				s+= unitList[i].StringForArray();
			}
			
			else {
				s+= unitList[i].StringForArray() + ", "; 
			}
		}
		 
		return s;
	}
	

	public String toString() {
		if (unitCount == 0) {
			return "Floor's utilized space is " +  0 + " sq ft (" + 500 + " sq ft remaining): []";
 
		}
		 
		else {
			return "Floor's utilized space is " +  sumCalc() + " sq ft (" + RemainingArea() + " sq ft remaining): ["  + ArraytoList() + "]";
		}

	}
	
    @Override
    public boolean equals(Object obj) {
        Floor other = (Floor) obj;
        
        int compare = sumCalc() - other.sumCalc(); 
    	
    	if(compare == 0 && measurement == other.measurement) {
    		return true;
    	}
    	
    	else {
    		return false;
    	} 

    } 
	 
	

}
