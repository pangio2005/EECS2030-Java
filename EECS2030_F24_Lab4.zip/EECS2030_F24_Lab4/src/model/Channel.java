package model;

public class Channel {
	public String name;
	private int followCount;
	public int videoCount;
	public int channelCount;

	public String[] videos;
	public String[] nameList;
	private Follower[] followerList;

	public Channel(String name, int MAX_FOLLOWS, int MAX_VIDS) {
		this.name = name;
		this.videos = new String[MAX_VIDS];
		this.followerList = new Follower[MAX_FOLLOWS];
		channelCount++;
	}
	
	public void releaseANewVideo(String currentVid) {
	    videos[videoCount] = currentVid;
	    videoCount++;
	    
	    for (int i = 0; i < followCount; i++) {
	        followerList[i].recommendVideo(currentVid);
	    }
	} 

	public void follow(Follower f1) {
		followerList[followCount] = f1;
		followCount++;
		f1.followChannel(this);
	}
 
	public void unfollow(Follower f1) {
	    for (int i = 0; i < followCount; i++) {
	        if (followerList[i] == f1) {
	            for (int j = i; j < followCount - 1; j++) {
	                followerList[j] = followerList[j + 1];
	            } 
	            followerList[followCount - 1] = null;
	            followCount--;
	            f1.removeChannel(this);
	        }
	    }
	}
	
	public void updateMon(String channelName, int watchTime) {
	    for (int i = 0; i < followCount; i++) {
	        followerList[i].updateStats(channelName, watchTime);
	    }
	}



	public String toString() {
		String s = "";

		if(followCount == 0) {
			if(videoCount == 0) {
				return name + " released no videos and has no followers.";
			}
			
			else {
				s+= name + " released <";
				 
				for (int i=0; i<videoCount;i++) {
					if(i == videoCount-1) {
						s+= videos[i];
					}

					else {
						s+= videos[i] + ", ";

					}
				}
			
				s+= "> and has no followers."; 
			}
		}
		
		else {
			if(videoCount == 0) {
				s+= name + " released no videos and is followed by [";
				
				for(int i=0; i<followCount;i++) {
					if(i == followCount-1) {
						s+= followerList[i].name;
					}
					
					else {
						s+= followerList[i].name + ", ";
					}
				}
				
				s+= "].";
			}
			
			else {
				s+= name + " released <";
				 
				for (int i=0; i<videoCount;i++) {
					if(i == videoCount-1) {
						s+= videos[i];
					}

					else {
						s+= videos[i] + ", ";

					}
				}
				
				s+= "> and is followed by [";
				
				for(int i=0; i<followCount;i++) {
					if(i == followCount-1) {
						s+= followerList[i].name;
					}
					
					else {
						s+= followerList[i].name + ", ";
					}
				}
				
				s+= "].";
				
				
			}
		}
		

		return s;
		
		
		
	}
	
		
}
