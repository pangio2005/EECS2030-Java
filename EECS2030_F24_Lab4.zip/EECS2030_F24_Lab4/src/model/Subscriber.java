package model;

public class Subscriber extends Follower {
	public String[] recs;
	public String ChannelName;
	public String avg;

	public int recCount;
	public int subCount;


	public Subscriber(String name, int maxFollowers, int maxRec) {
		super(maxFollowers);
		this.name = "Subscriber " + name;
		this.recs = new String[maxRec];
		this.subCount = 0;
		addSub(this); 
	}

	public void addSub(Subscriber s) {
		addFollower(s);
		subCount++;
	}

	@Override
	public void recommendVideo(String video) {
		recs[recCount] = video;
		recCount++;
	}

	public void watch(String video, int mins) {
		for (int i = 0; i < followedChannels.length; i++) {
			for (int j = 0; j < followedChannels[i].videos.length; i++) {
				if (followedChannels[i].videos[j].equals(video)) {
					followedChannels[i].updateMon(followedChannels[i].name, mins);
					return;
				}
			}
		}
	}


	public String toString() {
		String s="";
		if(recCount == 0) {
			if(channelCount == 0) {
				return name + " follows no channels and has no recommended videos.";
			}

			else {
				s += name + " follows [";

				for (int i = 0; i < channelCount; i++) {
					if(i == channelCount-1) {
						s+= followedChannels[i].name;

					} 


					else {
						s+= followedChannels[i].name + ", ";
					}



				}

				s += "] and has no recommended videos.";

				return s;
			}
		}

		else {;
		s += name + " follows [";

		for (int i = 0; i < channelCount; i++) {
			if(i == channelCount-1) {
				s+= followedChannels[i].name;

			}


			else {
				s+= followedChannels[i].name + ", ";
			}


		}


		s += "] and is recommended <";

		for(int i =0; i < recCount;i++) {
			if(i== recCount-1) {
				s+= recs[i];
			}

			else {
				s+= recs[i] + ", ";
			}
		}

		s+= ">.";

		return s;

		}
	}

}
