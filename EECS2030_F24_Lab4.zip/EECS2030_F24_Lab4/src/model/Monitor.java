package model;

public class Monitor extends Follower 
{	
	private int[][] stats;

	public Monitor(String name, int maxFollowedChannels) { 
		super(maxFollowedChannels);
		this.name = "Monitor " + name;
		this.stats = new int[maxFollowedChannels][4];
	}
	
	
	@Override
	public void updateStats(String channelName, int watchTime) {
		for (int i = 0; i < this.channelCount; i++){
			if (followedChannels[i].name.equals(channelName)){
				stats[i][0] += watchTime;
				stats[i][2]++;
				
				if (watchTime > stats[i][3]) {
					stats[i][3] = watchTime;
				}
			}
		}
	}

	
	

	public String getFollowedChannelsStringList() {
		String s = "[";
		for (int i = 0; i < channelCount; i++) {
			if (stats[i][0] == 0) {
				s += followedChannels[i].name;
			}
			
			else {
				s += String.format("%s {#views: %d, max watch time: %d, avg watch time: %.2f}", followedChannels[i].name, stats[i][2], stats[i][3], (double)stats[i][0] / stats[i][2]);
			}
			
			if (i != channelCount - 1) s += ", ";
		}
		
		s += "]";
		return s;
	}
	public String toString(){
		
		if (channelCount == 0) {
			return name + " follows no channels.";
		}
		
		return name + " follows " + getFollowedChannelsStringList() + ".";
				
	}
}
