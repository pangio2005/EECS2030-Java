package model;

public class Follower {
    public String name;
    public int followCount;
    public boolean isSub;
    public boolean isFol;


    public Follower[] followers;
    public Channel[] followedChannels;

    public int channelCount;
    public int followerCount;
    

    public Follower(int maxFollowers) {
        followedChannels = new Channel[maxFollowers];
        followers = new Follower[maxFollowers];

    } 
    

	public void followChannel(Channel channel) {
    	followedChannels[channelCount] = channel;
    	channelCount++;
    }
	
	void updateStats(String channelName, int watchTime) {
	}

	
	public void recommendVideo(String video) {
	}
	

    public void addFollower(Follower f) {
    	followerCount++;
    	followers[followerCount-1] = f;
    } 
    
    public void removeChannel(Channel c) {
	    for (int i = 0; i < channelCount; i++) {
	        if (followedChannels[i] == c) {
	            for (int j = i; j < channelCount - 1; j++) {
	                followedChannels[j] = followedChannels[j+1];
	            }
	            followedChannels[channelCount-1] = null;
	            channelCount--;
	        }
	    }
	}

 
      
}
 