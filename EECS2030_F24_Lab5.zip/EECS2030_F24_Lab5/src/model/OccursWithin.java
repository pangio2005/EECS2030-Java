package model;

public class OccursWithin implements BinarySeqOperation, SeqOperation {
	public int[] seq1;
	public int[] seq2;
	
	public OccursWithin(int[] seq1a, int[] seq2) {
		this.seq1 = seq1a;
		this.seq2 = seq2;
	}
	
	@Override
	public boolean excecuteOcc(int[] sequence, int[] array) {
	    for (int i = 0; i <= array.length - sequence.length; i++) {
	        boolean match = true;

	        for (int j = 0; j < sequence.length; j++) {
	            if (array[i + j] != sequence[j]) {
	                match = false;
	                break;
	            }
	        }

	        if (match) {
	            return true;
	        }
	    }

	    return false;
	}
	
	@Override
	public int[] excecute(int[] seq1, int[] seq2) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getResult() {
		if (excecuteOcc(seq1,seq2) == true) {
			return "true";
		}
		
		else {
			return "_";
		}
	}
	

	public String seqtoString(int[] seq) {
		String s="";
		for (int i=0;i < seq.length;i++) {
			if(i == seq.length - 1) {
				
				s+= seq[i];
			}
			
			else {
				s+= seq[i] + ", ";
			}

		}
		
		return s;
	}
	
	
	public String toString() {
		
		if(excecuteOcc(seq1,seq2) == false) {
			return "[" + seqtoString(seq1) + "] does not occur within [" + seqtoString(seq2) + "]";
		}
		
		else {
			return "[" + seqtoString(seq1) + "] occurs within [" + seqtoString(seq2) + "]";

		}
	}

	@Override
	public int getLen() {
		// TODO Auto-generated method stub
		return 0;
	}

}
