package model;

public class FilterAll implements SeqEvaluator {
    private final int maxOps;
    private int opCount;
    private SeqOperation[] operations;
    private int[] seq1;
    private int[] seq2;
    private boolean compat = true;

	public FilterAll(int max) {
		this.maxOps = max;
		this.operations = new SeqOperation[max];
	}

	@Override
	public void addOperation(String operationType, int[] seq1, int[] seq2) throws IllegalOperationException {
        if (operationType.equals("op:projection")) {
        	this.seq1= seq1;
        	this.seq2 = seq2;
        	compat = false;
            operations[opCount++] = new Projection(seq1, seq2);
        } 
        
        else if (operationType.equals("op:sumsOfPrefixes")) {
        	this.seq1= seq1;
        	compat = false;
            operations[opCount++] = new SumsOfPrefixes(seq1);
        } 
        
        else if(operationType.equals("op:occursWithin")) {
        	if(compat == false) {
        		compat = false;
        	}
        	
        	else {
        		this.seq1= seq1;
            	this.seq2 = seq2;
            	compat = true;
            	operations[opCount++] = new OccursWithin(seq1,seq2);
        	}

        }
        
        else {
            throw new IllegalOperationException();
        }
    }
	
	
	public String toString() {
		if(compat == false) {
			return "Filter cannot be evaluated due to 2 incompatile operations.";
		}
		
		else {
			String s = "";
			s+= "Filter result is: ";
			
			for(int i =0; i<opCount;i++) {
				
				

				if(i == opCount - 1) {
					s+= operations[i].getResult();
				}
				
				else {
					s+= operations[i].getResult() + ", ";
					
					

				}
				
			}
			
			
			
			
			return s;
		}
	}


}
