package model;

public class SumsOfPrefixes implements SeqOperation {
	public int[] seq;
	public int[] seq2; 


	public SumsOfPrefixes(int[] seq1) {
		this.seq = seq1; 
		this.seq2 = seq2;
	}
	
	public String seqtoString(int[] seq) {
		String s="";
		for (int i=0;i < seq.length;i++) {
			if(i == seq.length - 1) {
				
				s+= seq[i];
			}
			
			else {
				s+= seq[i] + ", ";
			}

		} 
		 
		return s;
	}
	
	public int[] excecute(int[] seq, int[] seq2) {
		int[] result = new int[seq.length + seq.length];
		result[0] = 0;
		int reslen = 1;
	    int sum = 0;
	    
	    for(int i=0;i<seq.length;i++) {
	    	sum = seq[i] + sum;
	    	result[i+1] = sum;
	    	reslen++;
	    }
	    
	    int[] trimmedResult = new int[reslen];
	    for (int i = 0; i < reslen; i++) {
	        trimmedResult[i] = result[i];
	    }

	    return trimmedResult; 
	}
	
	public String toString() {
		String s = "";
		
		s+= "Sums of prefixes of [" + seqtoString(seq) + "] is: [" + seqtoString(excecute(seq,seq2)) + "]";
		
		return s;
	}
	
	public int getLen() {
		return excecute(seq,seq2).length;
	}

	@Override
	public String getResult() {
		return seqtoString(excecute(seq,seq2));
	}


}
