package model;

public class IllegalOperationException extends Exception {
	public void IllegalOperationException() { 
		
	}

}
