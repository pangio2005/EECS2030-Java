package model;

public interface SeqOperation {

	int[] excecute(int[] seq1, int[] seq2);

	String getResult();
	int getLen();

}
