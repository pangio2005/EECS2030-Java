package model;

public interface SeqEvaluator {

	void addOperation(String string, int[] seq3, int[] seq2) throws IllegalOperationException;

}
