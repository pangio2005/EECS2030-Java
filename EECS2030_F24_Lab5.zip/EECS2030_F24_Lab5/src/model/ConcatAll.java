package model;

public class ConcatAll implements SeqEvaluator {
    private final int maxOps;
    private int opCount;
    private SeqOperation[] operations;
    private int[] seq1;
    private int[] seq2;
    private boolean compat = true;

	public ConcatAll(int max) {
		this.maxOps = max;
		this.operations = new SeqOperation[max];
	}

	public void addOperation(String operationType, int[] seq1, int[] seq2) throws IllegalOperationException {
		
        if (operationType.equals("op:projection")) {
        	if(compat == false) {
        		compat = false;
        	}
        	
        	else {
        		this.seq1= seq1;
            	this.seq2 = seq2;
            	compat = true;
                operations[opCount++] = new Projection(seq1, seq2);
        	}

        } 
        
        else if (operationType.equals("op:sumsOfPrefixes")) {
        	
        	if(compat == false) {
        		compat = false;
        	}
        	
        	else {
        		this.seq1= seq1;
            	compat = true;
                operations[opCount++] = new SumsOfPrefixes(seq1);
        	}

        } 
        
        else if(operationType.equals("op:occursWithin")) {
        	compat = false;
        }
        
        else {
            throw new IllegalOperationException();
        }
    }

	
	public String toString() {
		if(compat == false) {
			return "Concat cannot be evaluated due to 2 incompatile operations.";
		}
		
		else {
			String s = "";
			s+= "Concat(";
			
			for(int i =0; i<opCount;i++) {

				if(i == opCount - 1) {
					s+= "[" + operations[i].getResult() + "]";
				}
				
				else {
					s+= "[" + operations[i].getResult() + "], ";

				}
				
			}
		
			
			s+= ") = [";
			
			for(int i=0;i < opCount;i++) {
				if(i == opCount-1) {
					s+= operations[i].getResult();
				}
				
				else if(i== opCount-2 && operations[i+1].getResult() == "") {
					s+= operations[i].getResult();
				}
				
				else {
					s+= operations[i].getResult() + ", ";
				}

			}
			
			s+= "]";
			
			
			
			
			return s;
		}
		

	}





}
