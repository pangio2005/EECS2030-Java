package model;

public interface BinarySeqOperation extends SeqOperation {

	boolean excecuteOcc(int[] sequence, int[] array);

}
