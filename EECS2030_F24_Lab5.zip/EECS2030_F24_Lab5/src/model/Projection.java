package model;

public class Projection implements BinarySeqOperation, SeqOperation {
	public int[] seq1;
	public int[] seq2;
	public int[] result;

	public Projection(int[] seq1a, int[] seq2a) {
		this.seq1 = seq1a;
		this.seq2 = seq2a;
	    this.result = new int[seq1.length * seq2.length];
	}
	
	public String seqtoString(int[] seq) {
		String s="";
		for (int i=0;i < seq.length;i++) {
			if(i == seq.length - 1) {
				
				s+= seq[i];
			}
			
			else {
				s+= seq[i] + ", ";
			}

		}
		
		return s;
	}
	
	@Override
	public int[] excecute(int [] seq1, int [] seq2) {
		int reslen = 0;
	    int index = 0;

	    for (int j = 0; j < seq2.length; j++) {
	        for (int i = 0; i < seq1.length; i++) {
	            if (seq1[i] == seq2[j]) {
	                result[index] = seq1[i];
	                index++;
	                reslen++;
	                break;
	            }
	        }
	    }


	    int[] trimmedResult = new int[reslen];
	    for (int i = 0; i < reslen; i++) {
	        trimmedResult[i] = result[i];
	    }

	    return trimmedResult;	
	}
	
	public String getResult() {
		return seqtoString(excecute(seq1,seq2));
	}
	
	public int getLen() {
		return excecute(seq1,seq2).length;
	}
	 
	public String toString() {
		return "Projecting [" + seqtoString(seq1) + "] to [" + seqtoString(seq2) + "] results in: [" + seqtoString(excecute(seq1,seq2)) + "]";
	}
	
	@Override
	public boolean excecuteOcc(int[] sequence, int[] array) {
		return false;
	}



}
