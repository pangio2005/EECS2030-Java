package model;
import model.AppStore;
import model.App;

public class Account {
    private String name;
    private AppStore branch;
    private String[] downloadedApps;
    private int numDownloadAdd;
    private App[] downloadedObjects;
    private int numObjectAdd;
    private int toStringSwitcher;
    private String lastUninstalledAppName;
    private String lastSubmittedAppName;
    private int lastRating;
    private String lastDownloadedAppName;

    public Account(String name, AppStore branch) {
        this.name = name;
        this.branch = branch;
        this.downloadedApps = new String[50];
        this.downloadedObjects = new App[50];
        this.numDownloadAdd = 0;
        this.numObjectAdd = 0;
        this.toStringSwitcher = 0;
    }

    public String[] getNamesOfDownloadedApps() {
        String[] downloads = new String[numDownloadAdd];
        
        for (int i = 0; i < numDownloadAdd; i++) {
            downloads[i] = downloadedApps[i];
        }
        
        return downloads;
    }

    public App[] getObjectsOfDownloadedApps() {
        App[] objects = new App[numObjectAdd];
        
        for (int i = 0; i < numObjectAdd; i++) {
            objects[i] = downloadedObjects[i];
        }
        
        return objects;
    }

    public void uninstall(String appName) {
        boolean appFound = false;
        
        for (int i = 0; i < numDownloadAdd; i++) {
            if (downloadedApps[i].equals(appName)) {
                appFound = true;
                
                for (int j = i; j < numDownloadAdd - 1; j++) {
                    downloadedApps[j] = downloadedApps[j + 1];
                    downloadedObjects[j] = downloadedObjects[j + 1];
                }
                
                downloadedApps[numDownloadAdd - 1] = null;
                downloadedObjects[numObjectAdd - 1] = null;
                numDownloadAdd--;
                numObjectAdd--;
            }
        }

        if (appFound == false) {
            lastUninstalledAppName = appName;
            toStringSwitcher = 1;
        } 
        
        else {
            lastUninstalledAppName = appName;
            toStringSwitcher = 7;
        }
    }

    public void submitRating(String appName, int rating) {
        boolean appFound = false;
        
        for (int i = 0; i < numDownloadAdd; i++) {
            if (downloadedApps[i].equals(appName)) {
                appFound = true;
                App app = downloadedObjects[i];
                app.submitRating(rating);
                App appNameApp = branch.getApp(appName);
            }
        }

        if (appFound == false) {
            lastSubmittedAppName = appName;
            toStringSwitcher = 2;
        } 
        
        else {
        	lastSubmittedAppName = appName;
        	lastRating = rating;
            toStringSwitcher = 6;
        }
    }

    public void switchStore(AppStore appStore) {
        this.branch = appStore;
        toStringSwitcher = 3;
    }

    public void download(String appName) {
        boolean alreadyDownloaded = false;

        for (int i = 0; i < numDownloadAdd; i++) {
            if (downloadedApps[i].equals(appName)) {
                alreadyDownloaded = true;
                lastDownloadedAppName = appName;
                toStringSwitcher = 5;
            } 
        }

        if (!alreadyDownloaded) {
            App app = branch.getApp(appName);
            downloadedApps[numDownloadAdd] = appName;
            downloadedObjects[numObjectAdd] = app;
            numDownloadAdd++;
            numObjectAdd++;
            lastDownloadedAppName = appName;
            toStringSwitcher = 4;
        }
    }


    public String toString() {
        String s = "";

        if (toStringSwitcher == 0) {
            s += "An account linked to the " + branch.getBranch() + " store is created for " + name + ".";
        } 
        
        else if (toStringSwitcher == 1) {
            s += "Error: " + lastUninstalledAppName + " has not been downloaded for " + name + ".";
        } 
        
        else if (toStringSwitcher == 2) {
            s += "Error: " + lastSubmittedAppName + " is not a downloaded app for " + name + ".";
        } 
        
        else if (toStringSwitcher == 3) {
            s += "Account for " + name + " is now linked to the " + branch.getBranch() + " store.";
        } 
        
        else if (toStringSwitcher == 4) {
            s += lastDownloadedAppName + " is successfully downloaded for " + name + ".";
        } 
        
        else if (toStringSwitcher == 5) {
            s += "Error: " + lastDownloadedAppName + " has already been downloaded for " + name + ".";
        }
        
        else if (toStringSwitcher == 6) {
            s += "Rating score " + lastRating + " of " + name + " is successfully submitted for " + lastSubmittedAppName + ".";
        } 
        
        else if (toStringSwitcher == 7) {
        	s+= lastUninstalledAppName + " is successfully uninstalled for " + name + ".";
        }

        return s;
    }
}
