package model;

import model.Log;

public class App {
    private String appName;
    private Log[] updateHistory;
    private int updateCount;
    private int[] ratingList;
    private final int MAX_UPDATES = 20;
    private int ratingCount;

    public App(String appName, int maxRatings) {
        this.appName = appName;
        this.ratingCount = 0;
        this.updateCount = 0;
        this.updateHistory = new Log[MAX_UPDATES];
        this.ratingList = new int[5];
    }

    public String getName() { 
        return appName;
    }
    
    public int getUpdateCount() {
    	return updateCount;
    } 

    public Log[] getUpdateHistory() {
        Log[] updatesCurrent = new Log[this.updateCount];
        
        for (int i = 0; i < this.updateCount; i++) {
            updatesCurrent[i] = updateHistory[i];
        }
        
        return updatesCurrent;
    }

    public String getWhatIsNew() {
        if (updateCount == 0) {
            return "n/a"; 
        } 
         
        Log latestUpdate = this.updateHistory[this.updateCount - 1];
        return "Version " + latestUpdate.getVersion() + " contains " + latestUpdate.getNumberOfFixes() + " fixes " + latestUpdate.getFixes();
    }

    public Log getVersionInfo(String version) {
        for (int i = 0; i < updateCount; i++) {
            if (updateHistory[i].getVersion().equals(version)) {
                return updateHistory[i];
            }
        }
         
        return null;
    }  

    public String getRatingReport() {
        if (ratingCount == 0) {
            return "No ratings submitted so far!";
        } 
        
        else {
            return "Average of " + ratingCount + " ratings: " + String.format("%.1f", calculateAverage()) + " (Score 5: " + ratingList[4]  + ", Score 4: " + ratingList[3] + ", Score 3: " + ratingList[2] + ", Score 2: " + ratingList[1] + ", Score 1: " + ratingList[0] + ")";
        }
    }  

    public void releaseUpdate(String version) {
    	Log newLog = new Log(version);
    	updateHistory[updateCount] = newLog;
    	updateCount++;
    } 

    public void submitRating(int rating) {
    	ratingList[rating - 1] = ratingList[rating-1] + 1;
    	ratingCount++;
    } 

    private double calculateAverage() {
        double sum = 0;
        for (int i = 0; i < ratingList.length; i++) {
            sum += ratingList[i] * (i + 1);
        }
        
        double avg = sum / ratingCount;
        return avg; 
    }

    public String toString() { 
        String currentVersion = getWhatIsNew();

        if (ratingCount!= 0) {
        	String avgRating = String.format("%.1f", calculateAverage());
            return appName + " (Current Version: " + currentVersion + "; Average Rating: " + avgRating + ")";
        }
        
        else {
            return appName + " (Current Version: " + currentVersion + "; Average Rating: n/a" + ")";
        }
    }
}
