package model;
import model.App;
import model.Log;

public class AppStore {
	private String country;
	private App[] AppList;
	private int appcount;
	private int max_apps;
	private String[] StableList;

	
	public AppStore(String country, int max_apps) {
		this.country = country;
		this.AppList = new App[20];
	}
	
	public String getBranch() {
		return country;
	} 
		
	public App getApp(String appName) {
	    for (int i = 0; i < appcount; i++) {
	    	if (AppList[i].getName().equals(appName)) {
	    		return AppList[i];
	        }
	    } 
	    
	    return null;
	}
	
	public void addApp(App App) {
		AppList[appcount] = App;
		appcount++;
	} 
	
	public String toString(App App) {
		String s = "";
		s += App.getName() + " (" + App.getUpdateCount() + " versions; Current Version: " + App.getWhatIsNew() +")";
		return s;
	} 
	
	public String[] getStableApps(int num) {
	    int stablecount = 0;
	    String[] tempStables = new String[appcount];
	    for (int i = 0; i < appcount; i++) {
	    	
	        if (AppList[i].getUpdateCount() >= num) {
	            tempStables[stablecount] = toString(AppList[i]);
	            
	            stablecount++;
	        }
	    }
	
	    String[] Stables = new String[stablecount];	    


	    for (int i = 0; i < stablecount; i++) {
	        Stables[i] = tempStables[i];   
	    }
  
	    return Stables; 
	}
	


}
