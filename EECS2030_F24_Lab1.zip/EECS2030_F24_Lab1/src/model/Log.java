package model;

public class Log {    
    private String version;
    private String[] fixList;
    private int numFix;
    private int maxFixes = 10;
     
    public Log(String version) {
        this.version = version;
        this.numFix = 0;
        this.fixList = new String[this.maxFixes];
    }
       
    public String getVersion() { 
        return version;
    }
    
    public String getFixes() {
        String[] fix = new String[this.numFix];
        
        for (int i = 0; i < this.numFix; i++) {
            fix[i] = this.fixList[i]; 
        }
        
        String finalfix = TextMaker(fix); 
        return finalfix;
    } 
     
    public void addFix(String fix) {
         this.fixList[this.numFix] = fix;     
         this.numFix++;
         // no exception handling needed ty jackie :)
    }
    
    public int getNumberOfFixes() {
        return numFix;
    } 
    
    public String TextMaker(String[] fixes) {
        String s = "[";

        for (int i = 0; i < numFix; i++) {
            s += fixes[i];
            
            if (i < numFix - 1) {
                s += ", ";
            }
        } 
        
        s += "]"; 
        return s;
    }
    
    public String toString() { 
    	return "Version " + version + " contains " + numFix + " fixes " + TextMaker(fixList);
    }
}
