package model;

public class VaccineDistribution {
    private int doses;
    private String hospital;
    private String date;
    private Vaccine vaccine;

    public VaccineDistribution (Vaccine vaccine, int doses) {
        this.doses=doses;
        this.vaccine = vaccine;
    }

    public VaccineDistribution(Vaccine vaccine, String hospital,String date) {
        this.vaccine = vaccine;
        this.date = date;
        this.hospital = hospital;
    }

    public String getHospital() {
        return hospital;
    }

    public String getDate() {
        return date;
    }

    public Vaccine getVaccine() {
        return vaccine; 
    }

    public String toString() {
        String s = "";
        s+= doses + " doses of " + vaccine.getCodename() + " by " + vaccine.getMaker();

        return s; 
    }

}