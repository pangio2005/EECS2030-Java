package model;

public class Vaccine {
    private String codename;
    private String type;
    private String maker;


    public Vaccine(String codename, String type, String maker) {
        this.codename = codename; 
        this.type = type; 
        this.maker = maker;
    }

    public String getCodename() {
        return codename;
    }

    public String getType() {
        return type;
    }

    public String getMaker() {
        return maker;
    }

    public boolean Canadian() {
        boolean canadaType = true;

        if (codename != "mRNA-1273" && codename != "BNT162b2" && codename != "Ad26.COV2.S" && codename != "AZD1222" ) {
            canadaType = false;
        }

        return canadaType;
    }

    public String toString() {
        String s=""; 
        boolean canadaType = Canadian();
        if(canadaType == true) {
            s+= "Recognized vaccine: " + codename + " (" + type + "; " + maker + ")";
        }

        else {
            s+= "Unrecognized vaccine: " + codename + " (" + type + "; " + maker + ")";
        }

        return s;

    }


}