package model;

public class VaccinationSite {
    private String hospital;
    private int maxSupply;
    private String[] recordList;
    private int distribution;
    private int[] vacCount;
    private int dosage1;
    private int dosage2;
    private int dosage3;
    private int dosage4;
    private HealthRecord[] appointments;
    private int[] orderList;
    private int orderCounter;
    private int appCount;
    private String date;
    private String code;
    private Vaccine[] vaccineList;

    public VaccinationSite(String hospital, int maxSupply) {
        this.hospital = hospital;
        this.maxSupply = maxSupply; 
        this.distribution = 0; 
        this.appCount = 0;
        this.appointments = new HealthRecord[200];
        this.orderList = new int[4];
        this.recordList = new String[4];
        this.vacCount = new int[4]; 
        this.orderCounter = 1; 
        this.vaccineList = new Vaccine[4];
    }

    public void bookAppointment(HealthRecord patient) throws InsufficientVaccineDosesException {
        if ((distribution - appCount) <= 0) {
            patient.setAppointmentStatus("Last vaccination appointment for " + patient.getName() + " with " + hospital + " failed");
            throw new InsufficientVaccineDosesException("error");
        }
        
        else {
            appointments[appCount] = patient;
            appCount++;
            patient.setAppointmentStatus("Last vaccination appointment for " + patient.getName() + " with " + hospital + " succeeded");
        }
    }

    public int getNumberOfAvailableDoses() { 
        return distribution;
    }

    public int getNumberOfAvailableDoses(String type) {
        if (type.equals("mRNA-1273")) {
            return dosage1;
        }
        else if (type.equals("BNT162b2")) {
            return dosage2;
        }
        else if (type.equals("AZD1222")) {
            return dosage3;
        }
        else if (type.equals("Ad26.COV2.S")) {
            return dosage4;
        }
        
        else {
            return 0;
        }
    }

    public void addDistribution(Vaccine vaccine, int distribution) throws UnrecognizedVaccineCodeNameException, TooMuchDistributionException {
        code = vaccine.getCodename();
        this.distribution += distribution; 

        int index = -1;
        if (code.equals("mRNA-1273")) {
            index = 0;
        }
        else if (code.equals("BNT162b2")) {
            index = 1;
        }
        else if (code.equals("AZD1222")) {
            index = 2;
        }
        
        else if (code.equals("Ad26.COV2.S")) {
            index = 3;
        }      
        else {
            throw new UnrecognizedVaccineCodeNameException("Vaccine code name not recognized.");
        }

        vacCount[index] += distribution;

        if (index == 0) {
            dosage1 = vacCount[0];
        }
        else if (index == 1) {
            dosage2 = vacCount[1];
        }
        else if (index == 2) {
            dosage3 = vacCount[2];
        }
        else if (index == 3) {
            dosage4 = vacCount[3];
        }

        recordList[index] = vacCount[index] + " doses of " + vaccine.getMaker();

        if (orderList[index] == 0) {
            orderList[index] = orderCounter++;
            vaccineList[index] = vaccine;
        }

        if (this.distribution > maxSupply) {
            throw new TooMuchDistributionException("Total distribution exceeds maximum supply.");
        } 
    }  

    public void administer(String date) {
    	this.date = date;
    	for (int i = 0; i < appCount; i++) {
    		HealthRecord patient = appointments[i];
    		Vaccine vaccine = getNextAvailableVaccine();
    		patient.addRecord(vaccine, hospital, date);
    		decreaseVaccineCount(vaccine.getCodename());
    		distribution--;
    	}
    	
    	appCount = 0;
    }

    private Vaccine getNextAvailableVaccine() {
        int selectedIndex = -1;
        for (int i = 0; i < 4; i++) {
            if (vacCount[i] > 0 && (selectedIndex == -1 || orderList[i] < orderList[selectedIndex])) {
                selectedIndex = i;
            }
        }
        
        if (selectedIndex != -1) {
            return vaccineList[selectedIndex];
        }
        
        return null;
    }

    private void decreaseVaccineCount(String codename) {
        if (codename.equals("mRNA-1273")) {
            vacCount[0]--;
            dosage1--;
        }
        else if (codename.equals("BNT162b2")) {
            vacCount[1]--;
            dosage2--;
        }
        else if (codename.equals("AZD1222")) {
            vacCount[2]--;
            dosage3--;
        }
        else if (codename.equals("Ad26.COV2.S")) {
            vacCount[3]--;
            dosage4--;
        }
    }

    public String toString() { 
        String s = hospital + " has " + distribution + " available doses: <"; 
        boolean firstEntry = true;

        for (int i = 1; i < orderCounter; i++) {
            for (int j = 0; j < 4; j++) {
                if(orderList[j] == i) {
                    if (!firstEntry) {
                        s += ", ";
                    }
                    s += vacCount[j] + " doses of " + vaccineList[j].getMaker();
                    firstEntry = false;
                } 
            }
        }

        s += ">";
        return s; 
    } 

}
