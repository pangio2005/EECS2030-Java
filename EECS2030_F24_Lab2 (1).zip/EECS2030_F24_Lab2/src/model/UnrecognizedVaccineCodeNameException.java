package model;

public class UnrecognizedVaccineCodeNameException extends Exception {
    public UnrecognizedVaccineCodeNameException(String s) {
        super(s);
    }

}