package model;

public class HealthRecord {
    private String name;
    private VaccineDistribution[] records;
    private int recCount;  
    private String hospital; 
    private String appointmentStatus;

    public HealthRecord(String name, int lim) {
        this.name = name;
        this.records = new VaccineDistribution[lim]; 
        this.recCount = 0;                 
        this.hospital = "";                          
        this.appointmentStatus = "No vaccination appointment for " + name + " yet";
    }  

    public void addRecord(Vaccine vaccine, String hospital, String date) {
        records[recCount] = new VaccineDistribution(vaccine, hospital, date);
        this.hospital = hospital; 
        recCount++; 
    }  

    public String getName() {
        return name;
    }

    public String getVaccinationReceipt() {
        if (recCount == 0) {
            return name + " has not yet received any doses.";
        }

        String receipt = "Number of doses " + name + " has received: " + recCount + " [";

        for (int i = 0; i < recCount; i++) {
            VaccineDistribution record = records[i];
            Vaccine vaccine = record.getVaccine();
            String hospital = record.getHospital();
            String date = record.getDate();

            receipt += "Recognized vaccine: " + vaccine.getCodename() + " (" + vaccine.getType() + "; " + vaccine.getMaker() + ")";
            receipt += " in " + hospital + " on " + date;

            if (i < recCount - 1) {
                receipt += "; ";  
            }
        }

        receipt += "]";
        return receipt;
    } 

    public VaccineDistribution[] getRecord() {
        VaccineDistribution[] recordCopy = new VaccineDistribution[recCount];
        for (int i = 0; i < recCount; i++) {
            recordCopy[i] = records[i]; 
        }
        return recordCopy;
    }
  
    public String getAppointmentStatus() {
        return appointmentStatus;
    }
    
    public void setAppointmentStatus(String status) {
        this.appointmentStatus = status;
    }
}
