package junit_tests;

import model.GradingComponent;
import model.Performance;
import static org.junit.Assert.assertEquals;

import org.junit.Test;


/*
 * Problem:
 *
 * – You are required to implement a small system for managing student performance data.
 *
 * – Each performance data object is characterized by the name of a subject being registered for study (e.g., "EECS2030")
 * 		and a (possibly empty) array of grading components of that registered subject.
 *
 *   We assume that the maximum number of grading components of each performance data object is 10.
 *
 * – Each grading component is characterized by:
 * 		+ its name (e.g., Midterm 1)
 * 		+ its weight counted towards the final performance (e.g., 0.15234 which means 15.234 percents)
		+ its numerical result (e.g., 65)
 *
 *   For simplicity, we assume that the maximum result for each grading component is 100.
 *   Result of a grading component may be changed.
 *
 * – Given a performance data object, we may:
 * 		+ Register a new grading component.
 * 		+ Unregister a grading component whose name matches the input string.
 * 			You can assume that all registered grading components contain no duplicates of names.
 * 			(meaning that if the input name is an existing name of grading component,
 * 				there is only one “slot” in the array of grading components to be “removed”).
 *
 * 			If a non-existing name of grading component is given, then do nothing (without modifying anything).
 * 		+ Change the result of a grading component identified by some name (if that name exists).
 * 			If a non-existing name of grading component is given, then change nothing.
 * 		+ Return a textual report on the overall performance so far.
 * 		+ Return the progress so far.
 * 		+ Return the numerical result so far.
 *
 * - As an example, say in the student performance data object of HeeYeon for her EECS2030,
 * 		there are two grading components so far:
 * 			1. Midterm 1 (weighting 15% of the subject), for which she receives a result of 75 (marks)
 * 			2. Lab Test 1 (weighting 20% of the subject), for which she receives a result of 60 (marks)
 *
 *   Then HeeYeon’s progress so far is 15% + 20% = 35% (i.e., 0.35),
 *   	and her numerical result so far is: 75 * 0.15 + 60 * 0.2 = 23.25
 */

public class Tests {
    /*
     * 1. Do NOT create any new packages.
     * 		All classes you create must be in the `model` package.
     *
     * 2. All attributes you declare in the classes must be *** private ***.
     *
     * 3. You are free to create additional private or public helper methods.
     *
     * 4. You must NOT create any class not indicated by the given JUnit tests.
     *
     * 5. You must NOT put any System.out.print statements in the classes you create.
     *
     * 6. Programming Requirements:
     * 	- You are only allowed to use primitive arrays (e.g., int[], String[], Facility[])
     * 		for declaring attributes and implementing methods.
     * 	- Any use of a Java library class or method is forbidden
     * 		(that is, use selections and loops to build your solution from scratch instead):
     * 	- Here are some examples of forbidden classes/methods:
     * 		- Arrays class (e.g., Arrays.copyOf)
     * 		- System class (e.g., System.arrayCopy)
     * 		- ArrayList class
     * 		- String class (e.g., substring).
     * 	- The use of some library classes does not require an import statement,
     * 		but these classes are also forbidden to be used.
     * 	- Here are the exceptions (library methods which you are allowed to use if needed):
     * 		- String class (equals, format)
     *
     * You will receive a penalty as specified on the test guide if this requirement is violated.
     */

    /*
     * Your expected workflow should be:
     *
     * Step 1: Eliminate compilation errors.
     * 	Declare all the required classes and methods (returning default values if necessary),
     * 	so that the project contains no compilation errors (i.e., no red crosses shown on the Eclipse editor).
     *
     * Step 2: Pass all unit tests. Add private attributes and complete the method implementations accordingly,
     * 	so that executing all tests result in a green bar.
     *
     * If necessary, you are free to declare (private or public) helper methods.
     *
     * Any new classes that are ***not*** indicated by the given JUnit tests will be ***disregarded*** in grading.
     */

    /*
     * Tests related to the GradingComponent class.
     */

    @Test
    public void test_component_01a() {
        /*
         * Initialize a midterm grading component object
         * 	with initial name and weight.
         * The numerical result is uninitialized and left as default.
         *
         * Note. percentage value of the weight should be displayed with
         * 			3 digits after the decimal point.
         */
        GradingComponent m1 = new GradingComponent("Midterm 1", 0.154736);
        assertEquals("Component created: Midterm 1 accounts for 15.474 percents of the subject.", m1.toString());
    } 

    @Test
    public void test_component_01b() {
        /*
         * Initialize a midterm grading component object
         * with initial name and weight.
         * The numerical result is uninitialized and left as default.
         *
         * Note. percentage value of the weight should be displayed with
         * 			3 digits after the decimal point.
         */
        GradingComponent m1 = new GradingComponent("Midterm 1", 0.154736);

        /* Change the result of the midterm component. */
        m1.updateResult(75);
        assertEquals("Result of component Midterm 1 (accounting for 15.474 percents of the subject) is changed from 0 to 75.", m1.toString());

        m1.updateResult(83);
        assertEquals("Result of component Midterm 1 (accounting for 15.474 percents of the subject) is changed from 75 to 83.", m1.toString());
    }

    @Test
    public void test_component_01c() {
        /*
         * Initialize a midterm grading component object
         * with initial name and weight.
         * The result is uninitialized and left as default.
         *
         * Note. percentage value of the weight should be displayed with
         * 			3 digits after the decimal point.
         */
        GradingComponent m1 = new GradingComponent("Midterm 1", 0.154736);

        m1.updateResult(83);

        /* Change the weight of the midterm component. */
        m1.updateWeight(0.173834);
        assertEquals("Weight of component Midterm 1 (with result 83) is changed from 15.474 percents to 17.383 percents.", m1.toString());
    }

    /*
     * Tests related to the Performance class.
     */

    @Test
    public void test_performance_01() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");
        assertEquals("EECS2030", heeyeon.getSubject());

        /* no grading components so far -> empty list of components listed within [] */
        String report = heeyeon.getTextualPerformance();
        assertEquals("Number of components in EECS2030: 0 []", report);
 
        /*
         * For example calculations of the progress and numerical result,
         * 	see the Problem section at the top of this test file.
         */

        /* no components so far -> progress is 0.0 */
        assertEquals(0.0, heeyeon.getProgress(), 0.01);
        /* no components so far -> result is 0.0 */
        assertEquals(0.0, heeyeon.getNumericalPerformance(), 0.01);
    }   

    @Test
    public void test_performance_02() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        /* Register first component */
        heeyeon.register("Midterm 1", 0.153789, 75);
        /* Register second component */
        heeyeon.register("Midterm 2", 0.253783, 80);
        /*
         * Two components added
         *
         * Note. percentage value of the weight should be displayed with
         * 			3 digits after the decimal point.
         */
        assertEquals("Number of components in EECS2030: 2 [Midterm 1 (weight: 15.379 percents; result: 75), Midterm 2 (weight: 25.378 percents; result: 80)]", heeyeon.getTextualPerformance());
    }

    @Test
    public void test_performance_03() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        /*
         * For example calculations of the progress and numerical result,
         * 	see the Problem section at the top of this test file.
         */

        /* Register first component. */
        heeyeon.register("Midterm 1", 0.15, 75);
        assertEquals("Number of components in EECS2030: 1 [Midterm 1 (weight: 15.000 percents; result: 75)]", heeyeon.getTextualPerformance());
        assertEquals(0.15, heeyeon.getProgress(), 0.01);
        assertEquals(75 * 0.15, heeyeon.getNumericalPerformance(), 0.01);

        /* Register second component. */
        heeyeon.register("Midterm 2", 0.25, 80);
        assertEquals("Number of components in EECS2030: 2 [Midterm 1 (weight: 15.000 percents; result: 75), Midterm 2 (weight: 25.000 percents; result: 80)]", heeyeon.getTextualPerformance());
        assertEquals(0.15 + 0.25, heeyeon.getProgress(), 0.01);
        assertEquals(75 * 0.15 + 80 * 0.25, heeyeon.getNumericalPerformance(), 0.01);
    }

    @Test
    public void test_performance_04() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        /* Register two components. */
        GradingComponent m1 = new GradingComponent("Midterm 1", 0.15);
        m1.updateResult(75);
        GradingComponent m2 = new GradingComponent("Midterm 2", 0.25);
        m2.updateResult(80);

        heeyeon.register(m1);
        heeyeon.register(m2);

        /* Register two more components */
        heeyeon.register("Lab Test 1", 0.1, 90);
        heeyeon.register("Lab Test 2", 0.1, 95);

        /* four components registered so far */

        /*
         * For example calculations of the progress and numerical result,
         * 	see the Problem section at the top of this test file.
         */
        assertEquals("Number of components in EECS2030: 4 [Midterm 1 (weight: 15.000 percents; result: 75), Midterm 2 (weight: 25.000 percents; result: 80), Lab Test 1 (weight: 10.000 percents; result: 90), Lab Test 2 (weight: 10.000 percents; result: 95)]", heeyeon.getTextualPerformance());
        assertEquals(0.15 + 0.25 + 0.1 + 0.1, heeyeon.getProgress(), 0.01);
        assertEquals(75 * 0.15 + 80 * 0.25 + 90 * 0.1 + 95 * 0.1, heeyeon.getNumericalPerformance(), 0.01);
    }

    @Test
    public void test_performance_05() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        GradingComponent m1 = new GradingComponent("Midterm 1", 0.15);
        m1.updateResult(75);
        GradingComponent m2 = new GradingComponent("Midterm 2", 0.25);
        m2.updateResult(80);

        /* Register four components. */
        heeyeon.register(m1);
        heeyeon.register("Lab Test 1", 0.1, 90);
        heeyeon.register(m2);
        heeyeon.register("Lab Test 2", 0.1, 95);

        /* Change result of "Midterm 2"
         * Here "Midterm 2" is an existing component name.
         * You can assume that there are no duplicates of component names.
         */
        heeyeon.updatePerformance("Midterm 2", 85);

        /* Change result of "Midterm 3"
         * Here "Midterm 3" is a non-existing component name - do nothing.
         */
        heeyeon.updatePerformance("Midterm 3", 95);

        /* still four components registered so far */
        assertEquals("Number of components in EECS2030: 4 [Midterm 1 (weight: 15.000 percents; result: 75), Lab Test 1 (weight: 10.000 percents; result: 90), Midterm 2 (weight: 25.000 percents; result: 85), Lab Test 2 (weight: 10.000 percents; result: 95)]", heeyeon.getTextualPerformance());
        assertEquals(0.15 + 0.1 + 0.25 + 0.1, heeyeon.getProgress(), 0.01);
        assertEquals(75 * 0.15 + 90 * 0.1 + 85 * 0.25 + 95 * 0.1, heeyeon.getNumericalPerformance(), 0.01);
    } 

    @Test
    public void test_performance_06() {
        /*
         * Initialize a performance with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        /* Register two components. */
        GradingComponent m1 = new GradingComponent("Midterm 1", 0.15);
        m1.updateResult(75);
        heeyeon.register(m1);
        heeyeon.register("Lab Test 1", 0.1, 90);

        /* Two components added. */

        /*
         * For example calculations of the progress and numerical result,
         * 	see the Problem section at the top of this test file.
         */

        assertEquals("Number of components in EECS2030: 2 [Midterm 1 (weight: 15.000 percents; result: 75), Lab Test 1 (weight: 10.000 percents; result: 90)]", heeyeon.getTextualPerformance());
        assertEquals(0.15 + 0.1, heeyeon.getProgress(), 0.01);
        assertEquals(75 * 0.15 + 90 * 0.1, heeyeon.getNumericalPerformance(), 0.01);

        /*
         * Unregister the components for Midterm 1 and Lab Test 1
         * You can assume that there are no duplicates of
         * component names.
         */
        heeyeon.unregister("Midterm 1");
        heeyeon.unregister("Lab Test 1");

        /*
         * Unregister a non-existing component: do nothing.
         */
        heeyeon.unregister("Midterm 2");

        /* Zero components left after unregistering both components. */
        assertEquals("Number of components in EECS2030: 0 []", heeyeon.getTextualPerformance());
        assertEquals(0.0, heeyeon.getProgress(), 0.01);
        assertEquals(0.0, heeyeon.getNumericalPerformance(), 0.01);

        /*
         * Change result of "Midterm 1"
         * Here "Midterm 1" is a non-existing component name - do nothing.
         */
        heeyeon.updatePerformance("Midterm 1", 95);
        assertEquals("Number of components in EECS2030: 0 []", heeyeon.getTextualPerformance());
        assertEquals(0.0, heeyeon.getProgress(), 0.01);
        assertEquals(0.0, heeyeon.getNumericalPerformance(), 0.01);
    }

    @Test
    public void test_performance_07() {
        /*
         * Initialize a performance object with subject name.
         */
        Performance heeyeon = new Performance("EECS2030");

        /* Register one component. */
        heeyeon.register("Lab Test 1", 0.1, 90);

        /*
         * Unregister the component for Midterm 1
         * You can assume that there are no duplicates of
         * component names.
         */
        heeyeon.unregister("Midterm 1");

        /*
         * Unregister a non-existing component: do nothing.
         */
        heeyeon.unregister("Midterm 2");

        // Up to now, there should be just one component remaining in the list.

        // Register two new components
        heeyeon.register("Lab Test 2", 0.20, 75);
        heeyeon.register("Lab Test 3", 0.25, 95);

        /* Three components. */
        assertEquals("Number of components in EECS2030: 3 [Lab Test 1 (weight: 10.000 percents; result: 90), Lab Test 2 (weight: 20.000 percents; result: 75), Lab Test 3 (weight: 25.000 percents; result: 95)]", heeyeon.getTextualPerformance());
        assertEquals(0.1 + 0.2 + 0.25, heeyeon.getProgress(), 0.01);
        assertEquals(0.1 * 90 + 0.2 * 75 + 0.25 * 95, heeyeon.getNumericalPerformance(), 0.01);

        /* Change result of "Lab Test 2"
         * Here "Lab Test 2" is an existing component name.
         * You can assume that there are no duplicates of component names.
         */
        heeyeon.updatePerformance("Lab Test 2", 100);
        assertEquals("Number of components in EECS2030: 3 [Lab Test 1 (weight: 10.000 percents; result: 90), Lab Test 2 (weight: 20.000 percents; result: 100), Lab Test 3 (weight: 25.000 percents; result: 95)]", heeyeon.getTextualPerformance());
        assertEquals(0.1 + 0.2 + 0.25, heeyeon.getProgress(), 0.01);
        assertEquals(0.1 * 90 + 0.2 * 100 + 0.25 * 95, heeyeon.getNumericalPerformance(), 0.01);
    }

}