package model;

public class Performance {
	private String course;
	private int compCount;
	private GradingComponent[] grList;
	private double percList[];
	private double SmolPerc;
	
	public Performance(String course) {
		this.course = course;
		this.grList = new GradingComponent[1000];
		this.percList = new double[1000];
		
	}
	
	public String getSubject() {
		return course;
	}
	
	public String getTextualPerformance() {
		String s="";
		if (compCount == 0) {
			return "Number of components in " + course + ": 0 []";
		}
		
		else {
			s+= "Number of components in " + course + ": " + compCount + " [";
			for (int i=0;i<compCount;i++) {
				
				if(i == compCount-1) {
					s+= grList[i].getExam() + " (weight: " + grList[i].getPercent() + " percents; result: " + grList[i].getMark() + ")";
				} 
				
				
				else {
					s+= grList[i].getExam() + " (weight: " + grList[i].getPercent() + " percents; result: " + grList[i].getMark() + "), ";
				}
			}
			
			s+= "]";
			
			return s;	
		}
	} 
	
	public double getProgress() {
		return SmolPerc;
	}
	
	public double getNumericalPerformance() {
		return SmolPerc * grList[compCount-1].getMark();
	}
	
	public void register(String exam, double percentage, int mark) {
		compCount++;
		GradingComponent gr2 = new GradingComponent(exam, percentage, mark);
		SmolPerc = percentage;
		grList[compCount-1] = gr2;
	}
	
	
	public void register(GradingComponent gr) {
		compCount++;
		grList[compCount-1] = gr;
	}
	
	public void updatePerformance(String course, int mark) {
		
	}
	
	
	public void unregister(String course) {
		
	}
	
	
	
	
	

}
