package model;


public class GradingComponent {
	private String exam;
	private double percent;
	private int stringSwitch;
	private int mark;
	private int markCount;
	private int oldMark;
	private int[] marks;
	private double[] weights;
	private double percList;
	private double oldPerc;
	private int weightCount;
	
	public GradingComponent(String exam, double percent) {
		this.exam = exam;
		this.percent = percent; 
		this.stringSwitch = 0;
		this.marks = new int[1000];
		this.weights = new double[1000];
	}
	
	public GradingComponent(String exam, double percent, int mark) {
		this.exam = exam;
		this.percent = percent; 
		this.mark = mark;
		
	}
	
	public String getExam() {
		return exam;
	}
	
	public String getPercent() {
		double perc = percent * 100;
		return String.format("%.3f",(perc));
	}
	
	public double getSmolPerc() {
		return percent;
	}
	
	public int getMark() {
		return mark;
	}

	
	public void updateResult(int mark) {
		stringSwitch = 1;
		this.mark = mark;

		markCount++;
		
		marks[markCount] = mark;
		this.oldMark = marks[markCount - 1];
	}
	
	public void updateWeight(double weight) {
		stringSwitch = 2;
		weights[0] = percent; 
		this.percent = weight;

		weightCount++; 
		
		weights[weightCount] = percent;
		this.oldPerc = weights[weightCount - 1];
		
	}
	
	public String toString() {
		String s="";
		double perc = percent * 100;
		double oldPerc2 = oldPerc * 100;
		
		if (stringSwitch == 0) {
			s+= "Component created: " + exam + " accounts for " + String.format("%.3f",(perc)) + " percents of the subject.";
		}
		
		else if (stringSwitch == 1) {		
			s+= "Result of component " + exam + " (accounting for " + String.format("%.3f",(perc))  + " percents of the subject) is changed from " + oldMark + " to "+ mark + ".";
		}
		
		else if (stringSwitch == 2) {
			s+= "Weight of component " + exam + " (with result " + mark + ") is changed from " + String.format("%.3f",(oldPerc2)) + " percents to " + String.format("%.3f",(perc)) + " percents.";
		}
		
		 
		
		return s;
	}
	
	
	

}
