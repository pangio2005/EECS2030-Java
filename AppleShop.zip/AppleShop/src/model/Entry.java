package model;

// Template of a unit of storage in the apple refurbished shop
// Collection of entries

public class Entry {
	private String serialNumber; 
	private Product product;
	// reference type, will store the address of some Product object
	
	
	public Entry(String serialNumber,Product product ) {
		this.serialNumber = serialNumber;
		this.product = product;	
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}
	
	// Overloaded version of setProduct mutator
	
	public void setProduct(String model, double originalPrice) {
		//this.product = new Product(model, originalPrice); // whenever a new object is created use 'new'
		Product p = new Product(model,originalPrice);
		this.product = p;
	}
	
	public String toString() {
		return "[" + this.serialNumber + "]" + " " + this.product.toString();
	}
	
	
	

}
