package model;

/* 
 * Template of a collection of entries
 */

public class RefurbishedStore {
	private Entry[] entries; 
	private int noe; // counter
	private final int MAX_CAPACITY = 5; // a constant maximum capacity
	
	public RefurbishedStore() {
		this.entries = new Entry[MAX_CAPACITY];
		this.noe = 0;
		
	}
	
	public Entry[] getPrivateEntriesArray () {
		return this.entries;
	}
	
	public Entry[] getEntries() {
		Entry[] es = new Entry[this.noe];
		
		for (int i = 0; i< this.noe;i++) {
			es[i] = this.entries[i];
		}
		
		return es;
	}
	
	public int getNumberOfEntries() {
		return this.noe;
	}
	
	
	public void addEntry(Entry e){
		this.entries[this.noe] = e;	
		this.noe++;
	}
	
	public void addEntry(String sn, Product p) {
		//Entry ne = new Entry(sn,p);
		//this.entries[this.noe] = ne;	
		//this.noe++;
		this.addEntry(new Entry(sn,p));
	}
	
	public void addEntry(String sn, String model, double originalPrice) {
		//Product p = new Product (model,originalPrice);
		//Entry ne = new Entry(sn,p);
		//this.entries[this.noe] = ne;	
		//this.noe++;
		this.addEntry(new Entry(sn, new Product(model,originalPrice)));
	}
	
	
	public Product getProduct(String sn) {
		int index = -1; // expected to be re-assigned to a valid index if the sn exists
		// problematic exit condition: i < this.entries.length
		for (int i=0;i<this.noe;i++) {
			Entry e = this.entries[i];
			
			if (e.getSerialNumber().equals(sn)) {
				index = i;
			}
		}
		
		if (index<0) {
			return null;
		}
		
		else {
			return this.entries[index].getProduct();
		}
		
	}
	
	// Return sn of all products that are either space grey finish or is a pro
	public String[] getSpaceGreyOrPro() {
		int count = 0; // num of prod satisfying search
		int[] indices = new int[this.noe]; // indices of entry objects in entry array
		
		// Step 1: Collect all products satisfying
		for(int i =0;i<this.noe;i++) {
			Product p = this.entries[i].getProduct();
			
			if (p.getModel().contains("Pro") || (p.getFinish() != null && p.getFinish().equals("Space Grey"))) {
				indices[count] = i;
				count++;
			}	
		}
		
		// Step 2: Create an Array Of String (for sn) whose size is count
		String [] sns = new String[count];
		
		for(int i=0;i < count; i++) {
			sns[i] = this.entries[indices[i]].getSerialNumber();		
		}
		
		return sns;
	}
	
	// Return sn of all products that are both space grey finish or is a pro
	public String[] getSpaceGreyPro() {
		int count = 0; // num of prod satisfying search
		int[] indices = new int[this.noe]; // indices of entry objects in entry array
		
		// Step 1: Collect all products satisfying
		for(int i =0;i<this.noe;i++) {
			Product p = this.entries[i].getProduct();
			
			if (p.getModel().contains("Pro") && p.getFinish()!= null && p.getFinish().equals("Space Grey")) {
				indices[count] = i;
				count++;
			}	
		}
		
		// Step 2: Create an Array Of String (for sn) whose size is count
		String [] sns = new String[count];
		
		for(int i=0;i < count; i++) {
			sns[i] = this.entries[indices[i]].getSerialNumber();		
		}
		
		return sns;
	}
	
	
	
}
